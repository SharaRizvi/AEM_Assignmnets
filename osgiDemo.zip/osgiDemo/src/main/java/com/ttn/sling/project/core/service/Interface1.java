package com.ttn.sling.project.core.service;

public interface Interface1 {
    String getSimpleValue();
}
