package com.ttn.sling.project.core.service.impl;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.scripting.sightly.pojo.Use;

import javax.script.Bindings;

public class PoJOUse implements Use {
    @Override
    public void init(Bindings bindings) {
     //   Resource
    }
}
