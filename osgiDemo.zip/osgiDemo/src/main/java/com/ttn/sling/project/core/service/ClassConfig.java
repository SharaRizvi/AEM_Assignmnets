package com.ttn.sling.project.core.service;

public interface ClassConfig {

    boolean isClassLimitReached(int size);

    int getPassingMarks();

}