package com.ttn.sling.project.core.service;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class ReferenceDemo {
    private Logger logger= LoggerFactory.getLogger(this.getClass());

    @Reference
    Interface1 reference;

    @Activate
    public void activate(){
        logger.info("\n\n\nReferenceDemo.activate reference:"+reference.getSimpleValue()+", class: "+reference.getClass());
        logger.info("\n\n\n----------\n\n\n");
    }
}
