package com.ttn.core.servlets;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import javax.servlet.Servlet;
import java.io.*;

@Component(service=Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=Print Blog in PDF",
                "sling.servlet.methods=" + HttpConstants.METHOD_GET,
                "sling.servlet.paths="+ "/bin/downloadBlogs"
        })
public class PrintBlogPDFServlet extends SlingSafeMethodsServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(final SlingHttpServletRequest req,
                         final SlingHttpServletResponse resp) throws IOException {

        PrintWriter printWriter=resp.getWriter();

        String resourcePath="/content/SlingServlets/homepage/jcr:content";
        ResourceResolver resourceResolver = req.getResourceResolver();
        Resource resource = resourceResolver.getResource(resourcePath);

        //Displaying Blogs
        printWriter.print("Displaying All Blogs:->\n");
        for(Resource resource1:resource.getChildren()) {
            printWriter.println("Name: "+resource1.getName());
            printWriter.println("Publish Date: "+resource1.getValueMap().get("blog-date",resource1.getResourceType()));
            printWriter.println("Blog Title: "+resource1.getValueMap().get("blog-title",resource1.getResourceType()));
            printWriter.println("Blog Data: "+resource1.getValueMap().get("blog-data",resource1.getResourceType()));
            printWriter.println();
        }

    }
}